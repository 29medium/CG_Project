#ifndef GENERATOR_PLANE_H
#define GENERATOR_PLANE_H

#include "../../engine/headers/shape.h"

Shape* plane(float size);

#endif //GENERATOR_PLANE_H
