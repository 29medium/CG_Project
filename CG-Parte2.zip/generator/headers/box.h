#ifndef GENERATOR_BOX_H
#define GENERATOR_BOX_H

#include "../../engine/headers/shape.h"

Shape* box(float x, float y, float z, int divisions);

#endif //GENERATOR_BOX_H
